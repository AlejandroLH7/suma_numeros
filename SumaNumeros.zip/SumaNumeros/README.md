# SumaNumeros
Proyecto Java simple para sumar dos números, compatible con NetBeans 8.2.