package sumanumeros;

import java.util.Scanner;

public class Suma {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el primer número: ");
        int a = input.nextInt();
        System.out.print("Ingrese el segundo número: ");
        int b = input.nextInt();
        System.out.println("La suma es: " + (a + b));
    }
}
